<?php
/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              frontendmaker.com
 * @since             1.0.1
 * @package           Lotto_Feed
 *
 * @wordpress-plugin
 * Plugin Name:       Lotto Feed
 * Plugin URI:        frontendmaker.com
 * Description:       Shortcode samples: [lottery_feed number_of_lotteries="99" display_type="banner"]. Display types: banner, carousel, default, first-row
 * Version:           1.0.1
 * Author:            frontendmaker
 * Author URI:        frontendmaker.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       lotto-feed
 * Domain Path:       /languages
 */
// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-lotto-feed-activator.php
 */
function activate_lotto_feed() {
    require_once plugin_dir_path(__FILE__) . 'includes/class-lotto-feed-activator.php';
    Lotto_Feed_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-lotto-feed-deactivator.php
 */
function deactivate_lotto_feed() {
    require_once plugin_dir_path(__FILE__) . 'includes/class-lotto-feed-deactivator.php';
    Lotto_Feed_Deactivator::deactivate();
}

register_activation_hook(__FILE__, 'activate_lotto_feed');
register_deactivation_hook(__FILE__, 'deactivate_lotto_feed');

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path(__FILE__) . 'includes/class-lotto-feed.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */

function run_lotto_feed() {

    $plugin = new Lotto_Feed();

    //full lottery feed

    function lottery_feed_shortcode($atts) {
        
        $a = shortcode_atts( array(
            'number_of_lotteries' => '1',
            'display_type' => 'default' //carousel, default, banner, firstrow
        ), $atts );

        $curl = curl_init('https://www.lottoland.co.uk/lotteries');
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
        $page = curl_exec($curl);
        if (curl_errno($curl)) { // check for execution errors
            echo 'Scraper error: ' . curl_error($curl);
            exit;
        }
        curl_close($curl);

        $DOM = new DOMDocument;

        libxml_use_internal_errors(true);

        if (!$DOM->loadHTML($page)) {
            $errors = "";
            foreach (libxml_get_errors() as $error) {
                $errors.=$error->message . "<br/>";
            }
            libxml_clear_errors();
            print "libxml errors:<br>$errors";
            return;
        }
        $xpath = new DOMXPath($DOM);

        $case1 = $xpath->query('//*[@id="allLotteriesList-lotteries"]')->item(0);
        
        /* $query = 'div[not (@class="ads")]/span[1]'; */
        $titles = 'div[contains(@class,"lotteryTeaserBoxColumn")]';

        $entries = $xpath->query($titles, $case1);
        
        if($a['display_type'] == 'carousel') {
            echo '<div id="lottery-carousel" class="lotto-feed lotteries">';
        } elseif($a['display_type'] == 'banner') {
            echo '<div class="lotto-feed lottery-banner">';
        } elseif($a['display_type'] == 'firstrow') {
            echo '<div class="lotto-feed lotteries firstrow">';
        } else {
            echo '<div class="lotto-feed lotteries">';
        }
               
        $i = 0;
        foreach ($entries as $entry) {

            echo "<div class='single-lottery'> {$entry->ownerDocument->saveHTML($entry)} </div>";
            
            if(++$i == $a['number_of_lotteries']) break;
        }
        ?>

        </div>

            <?php
        }

        add_shortcode('lottery_feed', 'lottery_feed_shortcode');

    $plugin->run();
}

run_lotto_feed();

function add_plugin_scripts() {
    
    wp_enqueue_style('lotto-feed-styles', plugins_url('/css/lotto-feed-styles.css', __FILE__));
    wp_enqueue_style('lotto-owl-slider-styles', plugins_url('/css/owl.carousel.css', __FILE__));

    wp_enqueue_script('jquery', 'http://code.jquery.com/jquery-3.1.1.min.js');

    wp_enqueue_script('lotto-feed-scripts', plugins_url('/js/lotto-feed-scripts.js', __FILE__));
    wp_enqueue_script('lotto-owl-slider-scripts', plugins_url('/js/owl.carousel.min.js', __FILE__));
}

add_action('wp_enqueue_scripts', 'add_plugin_scripts');
