<?php

/**
 * Fired during plugin deactivation
 *
 * @link       frontendmaker.com
 * @since      1.0.0
 *
 * @package    Lotto_Feed
 * @subpackage Lotto_Feed/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Lotto_Feed
 * @subpackage Lotto_Feed/includes
 * @author     frontendmaker <mksolemn@gmail.com>
 */
class Lotto_Feed_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
