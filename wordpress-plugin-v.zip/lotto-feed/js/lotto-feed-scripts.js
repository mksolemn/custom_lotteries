(function ($) {

    $(document).ready(function ($) {

        var lottoModule = {};
        
        lottoModule = {
            buttonElement: '.button',
            lottoFeedWrapper: '#lottery-carousel',
            lottoFeedItem: '.single-lottery',
            itemsPerRow: 6,
            arrayToHide: [0,1,2,3,4,5,8,9,10,11,12,14,15,16,17,18,19,20,22,23,24],
            
            feedHeight: function() {
                var tallest = 0;
                $(this.lottoFeedItem).slice(0, this.itemsPerRow).each(function(){
                        if($(this).outerHeight() > tallest) {
                            tallest = $(this).outerHeight();
                        }
                });
                
                $(this.lottoFeedWrapper).css({
                    'height': tallest + 15 //adjust for sucking at js...
                });
            },
            
            launchCarousel: function() {
                
                //owl carousel
                $("#lottery-carousel").owlCarousel({
                    autoplay: 5000,
                    navigation: true,
                    navigationText : false,
                    autoPlay: true,
                    stopOnHover: true
                });
                
            },
            
            removeLotteries: function() {
                var self = this;
                $($(this.lottoFeedItem)).each(function(){
                    for(var i = 0; self.arrayToHide.length > i; i += 1) {
                            if($('.owl-item').length != 0) {
                                $('.single-lottery:eq('+self.arrayToHide[i]+')')
                                    .parent()
                                    .css({'display':'none'});
                            } else {
                                $('.single-lottery:eq('+self.arrayToHide[i]+')').css({'display':'none'});
                            }
                    }
                    $(self.lottoFeedItem).find('a').css('color','#18c3f7');
                });
                
            }
        };

        lottoModule.feedHeight();
        lottoModule.launchCarousel();
        lottoModule.removeLotteries();
        
        $(window).resize(function(){
            lottoModule.feedHeight();
        });
        
    });

})(jQuery);